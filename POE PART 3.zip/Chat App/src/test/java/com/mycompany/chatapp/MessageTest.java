/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;
import org.junit.Test;
import static org.junit.Assert.*;
/**
 *
 * @author Ngcebo
 */

public class MessageTest {

    @Test
    public void testCheckRecipientCell_Success() {
        Message msg = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String expected = "Cell phone number successfully captured.";
        String actual = msg.checkRecipientCell("+27718693002");
        assertEquals(expected, actual);
    }

    @Test
    public void testCheckRecipientCell_Failure() {
        Message msg = new Message(1, "08575975889", "Hi Keegan, did you receive the payment?");
        String expected = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        String actual = msg.checkRecipientCell("08575975889");
        assertEquals(expected, actual);
    }

    @Test
    public void testCreateMessageHash_Correctness() {
        Message msg = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String generatedID = msg.getMessageID();
        String expectedPrefix = generatedID.substring(0, 2);
        String expectedHash = expectedPrefix + ":0:HITONIGHT";
        assertEquals(expectedHash, msg.createMessageHash());
    }

    @Test
    public void testMessageContentLength_Success() {
        String validMessage = "Hi Mike, can you join us for dinner tonight?";
        assertTrue(validMessage.length() <= 250);
    }

    @Test
    public void testMessageContentLength_Failure() {
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 70; i++) {
            longMsg.append("text");
        }
        String invalidMessage = longMsg.toString();
        assertFalse(invalidMessage.length() <= 250);
    }
}